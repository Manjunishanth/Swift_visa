import os
import base64
import streamlit as st
import google.generativeai as genai
import wikipedia

# ---------- Gemini config ----------
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
MODEL = genai.GenerativeModel("models/gemini-2.5-flash")  # [web:9]

# ---------- Paths ----------
BASE = r"C:\Users\akhil\Downloads\SWIFT VISA"
RETR = os.path.join(BASE, "retrieved_chunks.txt")
EMBED_DIR = os.path.join(BASE, "chunked_output")
BG_IMAGE_PATH = os.path.join(BASE, "seven_wonders.jpg")   # background image
LOG_FILE = os.path.join(BASE, "qa_log.txt")               # Q&A log file


# ---------- Background helpers ----------
def set_background(image_path: str):
    """Set full‑page background using a local image (Seven Wonders collage)."""  # [web:13][web:17]
    if not os.path.exists(image_path):
        return
    with open(image_path, "rb") as img:
        encoded = base64.b64encode(img.read()).decode()
    css = f"""
    <style>
    [data-testid="stAppViewContainer"] {{
        background-image: url("data:image/jpg;base64,{encoded}");
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }}
    [data-testid="stHeader"] {{
        background: rgba(0,0,0,0.4);
        backdrop-filter: blur(6px);
    }}
    .block-container {{
        background: rgba(255,255,255,0.92);
        padding: 2rem;
        border-radius: 1.5rem;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    }}
    .stButton>button {{
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 0.5rem;
        padding: 0.5rem 2rem;
        font-weight: 600;
    }}
    .stButton>button:hover {{
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    }}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)


# ---------- RAG context loaders ----------
def load_retrieved():
    if os.path.exists(RETR):
        return open(RETR, encoding="utf-8").read().strip()
    return ""


def load_all_chunks():
    text = ""
    if not os.path.isdir(EMBED_DIR):
        return ""
    for folder in os.listdir(EMBED_DIR):
        fpath = os.path.join(EMBED_DIR, folder)
        if not os.path.isdir(fpath):
            continue
        for fname in os.listdir(fpath):
            if fname.endswith(".txt"):
                text += open(os.path.join(fpath, fname), encoding="utf-8").read() + "\n"
    return text.strip()


def search_external(question, country):
    """Short, up‑to‑date summary from Wikipedia to complement local chunks."""
    try:
        query = f"{country} visa {question} latest"
        summary = wikipedia.summary(query, sentences=4)  # [web:11]
        return summary
    except Exception:
        return None


# ---------- Intent & visa type ----------
def detect_visa_type(question: str):
    q = question.lower()
    if any(w in q for w in ["student", "study", "university", "college", "education", "ms", "mba", "phd"]):
        return "student"
    if any(w in q for w in ["work", "job", "employment", "h1b", "skilled", "worker"]):
        return "work"
    if any(w in q for w in ["business", "entrepreneur", "invest", "startup"]):
        return "business"
    if any(w in q for w in ["tourist", "visit", "travel", "tourism", "vacation"]):
        return "tourist"
    return None


def is_eligibility_question(q: str) -> bool:
    q = q.lower()
    phrases = [
        "am i eligible",
        "am i eligable",
        "eligible for",
        "eligibility for",
        "can i get this visa",
        "will i get this visa",
        "do i qualify",
    ]
    return any(p in q for p in phrases)


# ---------- LLM call ----------
def ask_model(question, context, country, user_details=None):
    details_text = ""
    if user_details:
        details_lines = [f"- {k}: {v}" for k, v in user_details.items() if str(v).strip() != ""]
        if details_lines:
            details_text = "\n\nApplicant Details:\n" + "\n".join(details_lines)

    prompt = f"""
You are an expert visa consultant. Use the context and, only when needed, general up-to-date visa rules.
Always answer the user's exact question. Do not change the topic.

Country: {country}

Context (visa rules, fees, eligibility, etc. from internal visa docs and public sources):
\"\"\"{context}\"\"\"
{details_text}

Question:
\"\"\"{question}\"\"\"

Instructions:
- Answer clearly and concisely.
- If the exact information (for example, fee or document list) is not in the context or may be outdated,
  say that it can vary and advise the user to confirm on the official visa website, then give a general explanation.
- If applicant details are provided and the user is asking about eligibility, you must:
  1) State if the person is Likely eligible / Possibly eligible / Unlikely to be eligible.
  2) Give 2–3 short reasons.
  3) End the answer with a line: "Confidence: XX%" where XX is a number from 0 to 100.

Return only the final answer for the user.
"""
    resp = MODEL.generate_content(prompt)
    return resp.text.strip()


# ---------- Logging helper ----------
def save_qa_to_file(question, answer):
    """
    Append question, answer, and confidence line (if present) to qa_log.txt. [web:29]
    """
    confidence_line = ""
    for line in reversed(answer.splitlines()):
        if line.strip().lower().startswith("confidence:"):
            confidence_line = line.strip()
            break

    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write("----\n")
        f.write(f"Q: {question}\n\n")
        f.write("A:\n")
        f.write(answer.strip() + "\n")
        if confidence_line:
            f.write(confidence_line + "\n")
        f.write("----\n\n")


# ---------- Streamlit config ----------
st.set_page_config(page_title="SWIFT VISA Assistant", layout="wide")
set_background(BG_IMAGE_PATH)

# Session state
if "show_form" not in st.session_state:
    st.session_state.show_form = False
if "submitted" not in st.session_state:
    st.session_state.submitted = False
if "user_details" not in st.session_state:
    st.session_state.user_details = {}
if "visa_type" not in st.session_state:
    st.session_state.visa_type = None

# ---------- UI ----------
st.title("🌍 SWIFT VISA — Smart Visa Assistant")
st.markdown("### Get instant, personalized answers to your visa questions")

countries = ["United States", "United Kingdom", "Canada", "Ireland", "Schengen / Europe"]
country = st.selectbox("🌐 Select destination country:", countries)

question = st.text_input(
    "💬 Ask your visa question:",
    placeholder="e.g., What are the requirements for studying MS in USA?",
)

if question:
    visa_type = detect_visa_type(question)
    st.session_state.visa_type = visa_type
    needs_form = is_eligibility_question(question) or (visa_type is not None)
    if needs_form:
        st.session_state.show_form = True

# ---------- Details form ----------
user_details = {}

if st.session_state.show_form and question:
    visa_type = st.session_state.visa_type or "general"
    st.info("📋 Please fill your details so that eligibility and risk can be assessed more accurately.")

    st.markdown("---")
    st.subheader(f"📝 {visa_type.upper()} Visa Applicant Details")

    # Common fields
    col1, col2 = st.columns(2)
    with col1:
        user_details["Full Name"] = st.text_input("Full Name")
        user_details["Date of Birth (DD/MM/YYYY)"] = st.text_input("Date of Birth")
        user_details["Passport Validity (months remaining)"] = st.text_input("Passport Validity (months)")
        user_details["Country of Citizenship"] = st.text_input("Country of Citizenship")
    with col2:
        user_details["Current City"] = st.text_input("Current City")
        user_details["Financial Capacity (approx. funds in USD)"] = st.text_input("Available Funds (USD)")
        user_details["Previous International Travel"] = st.selectbox(
            "Have you traveled abroad before?", ["Select", "Yes", "No"]
        )
        user_details["Any Visa Refusals Before"] = st.selectbox(
            "Any previous visa refusals?", ["Select", "Yes", "No"]
        )

    # Visa-type specific
    if visa_type == "student":
        st.markdown("#### Education details")
        c1, c2 = st.columns(2)
        with c1:
            user_details["Previous University"] = st.text_input("Previous University/College")
            user_details["Highest Qualification"] = st.text_input("Highest Qualification")
            user_details["Intended Degree"] = st.selectbox(
                "Intended Degree", ["Select", "Bachelor's", "Master's", "PhD", "Diploma"]
            )
        with c2:
            user_details["Overall CGPA/Percentage"] = st.text_input("Overall CGPA or Percentage")
            user_details["English Test Score (IELTS/TOEFL/etc)"] = st.text_input("English Test Score")
            user_details["Can Show Financial Proof"] = st.selectbox(
                "Can you show sufficient financial proof?", ["Select", "Yes", "No", "Partial"]
            )

    elif visa_type == "work":
        st.markdown("#### Work details")
        c1, c2 = st.columns(2)
        with c1:
            user_details["Current/Previous Job Title"] = st.text_input("Current/Previous Job Title")
            user_details["Years of Work Experience"] = st.number_input(
                "Years of Work Experience", min_value=0, max_value=50, step=1
            )
        with c2:
            user_details["Highest Education"] = st.selectbox(
                "Highest Education", ["Select", "High School", "Bachelor's", "Master's", "PhD"]
            )
            user_details["Job Offer in Destination Country"] = st.selectbox(
                "Do you already have a job offer?", ["Select", "Yes", "No"]
            )

    elif visa_type == "business":
        st.markdown("#### Business / investment details")
        c1, c2 = st.columns(2)
        with c1:
            user_details["Type of Business"] = st.text_input("Type of Business")
            user_details["Planned Investment (USD)"] = st.text_input("Planned Investment (USD)")
        with c2:
            user_details["Business Experience (years)"] = st.number_input(
                "Years in Business", min_value=0, max_value=50, step=1
            )
            user_details["Business Plan Ready"] = st.selectbox(
                "Do you have a structured business plan?", ["Select", "Yes", "No"]
            )

    elif visa_type == "tourist":
        st.markdown("#### Trip details")
        c1, c2 = st.columns(2)
        with c1:
            user_details["Purpose of Visit"] = st.text_input("Purpose of Visit (tourism/family/etc.)")
            user_details["Intended Stay Duration (days)"] = st.text_input("Intended Stay Duration (days)")
        with c2:
            user_details["Employment Status"] = st.selectbox(
                "Current Employment Status",
                ["Select", "Employed", "Self-Employed", "Retired", "Student", "Unemployed"],
            )
            user_details["Return Ticket Booked"] = st.selectbox(
                "Return ticket booked?", ["Select", "Yes", "No", "Not yet"]
            )

    st.markdown("")
    c1, c2, c3 = st.columns([1, 1, 1])
    with c2:
        if st.button("🚀 Submit & Get Assessment", use_container_width=True):
            if user_details.get("Full Name", "").strip():
                st.session_state.user_details = user_details
                st.session_state.submitted = True
                st.rerun()
            else:
                st.error("Please enter at least your Full Name before submitting.")

# ---------- Assessment branch ----------
if st.session_state.submitted and question:
    with st.spinner("🔍 Analyzing your application and generating response..."):
        ctx = load_retrieved()
        if not ctx:
            ctx = load_all_chunks()
        external_info = search_external(question, country)
        if external_info:
            ctx = (ctx + "\n\n" + external_info) if ctx else external_info
        ctx = ctx[:50000]

        answer = ask_model(question, ctx, country, st.session_state.user_details)
        save_qa_to_file(question, answer)

        st.markdown("---")
        st.subheader("✅ Assessment Result")
        st.write("Here is a generated response using the available visa documents and current public information.")
        st.write(answer)

        if st.button("🔄 Start New Query"):
            st.session_state.clear()
            st.rerun()

# ---------- Simple Q&A branch ----------
elif question and not st.session_state.show_form:
    if st.button("Get Answer"):
        with st.spinner("🔍 Generating response..."):
            ctx = load_retrieved()
            if not ctx:
                ctx = load_all_chunks()
            external_info = search_external(question, country)
            if external_info:
                ctx = (ctx + "\n\n" + external_info) if ctx else external_info
            ctx = ctx[:50000]

            answer = ask_model(question, ctx, country)
            save_qa_to_file(question, answer)

            st.markdown("---")
            st.subheader("📌 Answer")
            st.write("Here is a generated response using the available visa documents and current public information.")
            st.write(answer)

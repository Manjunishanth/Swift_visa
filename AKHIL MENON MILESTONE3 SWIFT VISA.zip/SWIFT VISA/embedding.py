import os, json
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")
os.makedirs("embeddings", exist_ok=True)

for fname in os.listdir("chunked_output"):
    if fname.endswith(".txt"):
        with open(os.path.join("chunked_output", fname), "r", encoding="utf-8") as f:
            chunks = [line.strip() for line in f if line.strip()]
        embedding = model.encode(chunks).tolist()
        with open(os.path.join("embeddings", f"{os.path.splitext(fname)[0]}_embedding.json"), "w", encoding="utf-8") as f:
            json.dump({"chunks": chunks, "embedding": embedding}, f, indent=2)

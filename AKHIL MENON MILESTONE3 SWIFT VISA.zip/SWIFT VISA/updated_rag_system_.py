import os
import google.generativeai as genai

genai.configure(api_key=os.getenv("GENAI_API_KEY"))
model = genai.GenerativeModel("models/gemini-2.5-flash")

BASE = r"C:\Users\akhil\Downloads\SWIFT VISA"
RETR = os.path.join(BASE, "retrieved_chunks.txt")
CHUNK_DIR = os.path.join(BASE, "chunked_output")
EMBED_DIR = os.path.join(BASE, "embedding")
HISTORY = os.path.join(BASE, "qa_history.txt")


def load_retrieved():
    if os.path.exists(RETR):
        return open(RETR, encoding="utf-8").read().strip()
    return ""


def load_all_chunks():
    text = ""
    for folder in [CHUNK_DIR, EMBED_DIR]:
        if not os.path.isdir(folder): continue
        for f in os.listdir(folder):
            if f.endswith(".txt"):
                text += open(os.path.join(folder, f), encoding="utf-8").read() + "\n"
    return text.strip()


def build_context():
    ctx = load_retrieved()
    if not ctx:                         # fallback if retrieved empty
        ctx = load_all_chunks()
    return ctx[:40000]                  # keep context small


# Ask → Answer → Save history
while True:
    q = input("\nAsk (exit): ").strip()
    if q.lower() == "exit": break

    ctx = build_context()
    if not ctx:
        print("No context found.")
        continue

    prompt = f"Answer ONLY from this context:\n{ctx}\n\nQuestion: {q}"
    ans = model.generate_content(prompt).text.strip()

    with open(HISTORY, "a", encoding="utf-8") as f:
        f.write(f"Q: {q}\nA: {ans}\n\n")

    print("\n", ans, "\n")

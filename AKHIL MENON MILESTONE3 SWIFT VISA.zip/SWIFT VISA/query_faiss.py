import os
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings

BASE = r"C:\Users\akhil\Downloads\SWIFT VISA"
CHUNK_DIR = os.path.join(BASE, "chunked_output")
DB_DIR = os.path.join(BASE, "langchain_faiss_db")
OUT = os.path.join(BASE, "retrieved_chunks.txt")

embed = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

# Load OR create FAISS DB
if os.path.exists(DB_DIR):
    db = FAISS.load_local(DB_DIR, embed, allow_dangerous_deserialization=True)
else:
    texts, metas = [], []
    for f in os.listdir(CHUNK_DIR):
        if f.endswith(".txt"):
            text = open(os.path.join(CHUNK_DIR, f), encoding="utf-8").read()
            texts.append(text)
            metas.append({"source": f})
    db = FAISS.from_texts(texts, embed, metadata=metas)
    db.save_local(DB_DIR)


# Query loop → save retrieved chunks
while True:
    q = input("\nQuery (exit): ").strip()
    if q.lower() == "exit": break

    results = db.similarity_search(q, k=5)

    with open(OUT, "w", encoding="utf-8") as f:
        for r in results:
            f.write(r.page_content + "\n")

    print("Saved to retrieved_chunks.txt")

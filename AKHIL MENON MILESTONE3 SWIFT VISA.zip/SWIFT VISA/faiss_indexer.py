import os, json, numpy as np, faiss

BASE = r"C:\Users\Akhil\Downloads\SWIFT VISA"
EMB = os.path.join(BASE, "embeddings")
OUT = os.path.join(BASE, "faiss_output")
IDX = os.path.join(OUT, "faiss.index")
NPY = os.path.join(OUT, "vectors.npy")

os.makedirs(EMB, exist_ok=True)
os.makedirs(OUT, exist_ok=True)

vecs = []

for f in os.listdir(EMB):
    if f.endswith(".json"):
        with open(os.path.join(EMB, f), "r", encoding="utf-8") as fp:
            data = json.load(fp)

        if isinstance(data, dict):
            data = [data]

        for item in data:
            if "embedding" in item:
                v = np.array(item["embedding"], dtype="float32")
                vecs.append(v)

if not vecs:
    print(" No embeddings found.")
    exit()

arr = np.vstack(vecs)
np.save(NPY, arr)

index = faiss.IndexFlatL2(arr.shape[1])
index.add(arr)
faiss.write_index(index, IDX)

print(" FAISS index created successfully")
print(" Vectors saved at:", NPY)
print(" Index saved at:", IDX)
